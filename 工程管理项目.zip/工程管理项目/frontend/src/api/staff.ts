﻿import http from './http'

export interface StaffForm {
  staffId: string
  realName: string
  gender?: string
  phone?: string
  email?: string
  staffStatus?: string
}

export async function getStaff(keyword?: string) {
  const { data } = await http.get('/staff', { params: { keyword } })
  return data
}

export async function createStaff(payload: StaffForm) {
  const { data } = await http.post('/staff', payload)
  return data
}

export async function updateStaff(id: string, payload: StaffForm) {
  const { data } = await http.put(`/staff/${id}`, payload)
  return data
}

export async function deleteStaff(id: string) {
  const { data } = await http.delete(`/staff/${id}`)
  return data
}
