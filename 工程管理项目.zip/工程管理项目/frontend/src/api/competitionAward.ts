﻿import http from './http'

export interface CompetitionAwardForm {
  awardId?: number
  studentId: string
  realName: string
  competitionName: string
  competitionSession?: string
  awardGrade?: string
  awardDate?: string
  auditStatus?: string
  remarks?: string
}

export async function getCompetitionAwards(keyword?: string, auditStatus?: string) {
  const { data } = await http.get('/edu/competition-awards', { params: { keyword, auditStatus } })
  return data
}

export async function createCompetitionAward(payload: CompetitionAwardForm) {
  const { data } = await http.post('/edu/competition-awards', payload)
  return data
}

export async function updateCompetitionAward(id: number, payload: CompetitionAwardForm) {
  const { data } = await http.put(`/edu/competition-awards/${id}`, payload)
  return data
}

export async function deleteCompetitionAward(id: number) {
  const { data } = await http.delete(`/edu/competition-awards/${id}`)
  return data
}

export async function auditCompetitionAward(id: number, auditStatus: string, remarks?: string) {
  const { data } = await http.patch(`/edu/competition-awards/${id}/audit`, { auditStatus, remarks })
  return data
}
