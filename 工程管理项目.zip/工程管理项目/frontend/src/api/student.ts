﻿import http from './http'

export interface StudentForm {
  studentId: string
  studentName: string
  major?: string
  currentGrade?: string
  studentType?: string
}

export async function getStudents(keyword?: string) {
  const { data } = await http.get('/students', { params: { keyword } })
  return data
}

export async function createStudent(payload: StudentForm) {
  const { data } = await http.post('/students', payload)
  return data
}

export async function updateStudent(id: string, payload: StudentForm) {
  const { data } = await http.put(`/students/${id}`, payload)
  return data
}

export async function deleteStudent(id: string) {
  const { data } = await http.delete(`/students/${id}`)
  return data
}
