﻿import LoginPage from '../views/login/LoginPage.vue'
import BasicLayout from '../layouts/BasicLayout.vue'
import DashboardPage from '../views/dashboard/DashboardPage.vue'
import StudentPage from '../views/student/StudentPage.vue'
import StaffPage from '../views/staff/StaffPage.vue'
import CompetitionAwardPage from '../views/edu/CompetitionAwardPage.vue'

export const routes = [
  { path: '/login', component: LoginPage },
  {
    path: '/',
    component: BasicLayout,
    children: [
      { path: '', component: DashboardPage },
      { path: 'students', component: StudentPage },
      { path: 'staff', component: StaffPage },
      { path: 'competition-awards', component: CompetitionAwardPage }
    ]
  }
]
