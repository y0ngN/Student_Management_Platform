﻿<template>
  <el-container style="height: 100vh">
    <el-aside width="220px" style="background: #1f2937; color: #fff; padding: 16px">
      <h3 style="color: #fff">学生管理平台</h3>
      <el-menu router background-color="#1f2937" text-color="#fff" active-text-color="#ffd04b">
        <el-menu-item index="/">仪表盘</el-menu-item>
        <el-menu-item index="/students">学生管理</el-menu-item>
        <el-menu-item index="/staff">教职工管理</el-menu-item>
        <el-menu-item index="/competition-awards">竞赛获奖</el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header style="display:flex;justify-content:space-between;align-items:center">
        <div>欢迎，{{ username }}</div>
        <el-button type="danger" size="small" @click="doLogout">退出登录</el-button>
      </el-header>
      <el-main>
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
const router = useRouter()
const username = computed(() => auth.username)

function doLogout() {
  auth.logout()
  router.push('/login')
}
</script>
