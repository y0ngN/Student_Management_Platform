﻿<template>
  <el-card>
    <template #header>
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <span>教职工管理</span>
        <div style="display:flex;gap:8px">
          <el-input v-model="keyword" placeholder="按工号/姓名搜索" style="width:220px" @keyup.enter="load" />
          <el-button @click="load">查询</el-button>
          <el-button type="primary" @click="openCreate">新增教职工</el-button>
        </div>
      </div>
    </template>

    <el-table :data="rows" stripe>
      <el-table-column prop="staffId" label="工号" />
      <el-table-column prop="realName" label="姓名" />
      <el-table-column prop="gender" label="性别" />
      <el-table-column prop="phone" label="手机" />
      <el-table-column prop="email" label="邮箱" />
      <el-table-column prop="staffStatus" label="状态" />
      <el-table-column label="操作" width="180">
        <template #default="scope">
          <el-button link type="primary" @click="openEdit(scope.row)">编辑</el-button>
          <el-button link type="danger" @click="remove(scope.row.staffId)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>

  <el-dialog v-model="visible" :title="isEdit ? '编辑教职工' : '新增教职工'" width="520px">
    <el-form label-width="90px">
      <el-form-item label="工号">
        <el-input v-model="form.staffId" :disabled="isEdit" />
      </el-form-item>
      <el-form-item label="姓名">
        <el-input v-model="form.realName" />
      </el-form-item>
      <el-form-item label="性别">
        <el-select v-model="form.gender" style="width:100%">
          <el-option label="男" value="男" />
          <el-option label="女" value="女" />
        </el-select>
      </el-form-item>
      <el-form-item label="手机">
        <el-input v-model="form.phone" />
      </el-form-item>
      <el-form-item label="邮箱">
        <el-input v-model="form.email" />
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="form.staffStatus" style="width:100%">
          <el-option label="在职" value="在职" />
          <el-option label="离职" value="离职" />
          <el-option label="退休" value="退休" />
        </el-select>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible=false">取消</el-button>
      <el-button type="primary" @click="save">保存</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { createStaff, deleteStaff, getStaff, updateStaff, type StaffForm } from '../../api/staff'

const keyword = ref('')
const rows = ref<StaffForm[]>([])
const visible = ref(false)
const isEdit = ref(false)
const form = reactive<StaffForm>({ staffId: '', realName: '', gender: '男', phone: '', email: '', staffStatus: '在职' })

async function load() {
  const res = await getStaff(keyword.value)
  rows.value = res.data || []
}

function openCreate() {
  isEdit.value = false
  Object.assign(form, { staffId: '', realName: '', gender: '男', phone: '', email: '', staffStatus: '在职' })
  visible.value = true
}

function openEdit(row: StaffForm) {
  isEdit.value = true
  Object.assign(form, row)
  visible.value = true
}

async function save() {
  if (!form.staffId || !form.realName) {
    ElMessage.warning('工号和姓名不能为空')
    return
  }
  if (isEdit.value) {
    await updateStaff(form.staffId, form)
    ElMessage.success('修改成功')
  } else {
    await createStaff(form)
    ElMessage.success('新增成功')
  }
  visible.value = false
  await load()
}

async function remove(id: string) {
  await ElMessageBox.confirm(`确认删除教职工 ${id} 吗？`, '提示', { type: 'warning' })
  await deleteStaff(id)
  ElMessage.success('删除成功')
  await load()
}

onMounted(load)
</script>
