﻿<template>
  <el-card>
    <template #header>
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <span>学生管理</span>
        <div style="display:flex;gap:8px">
          <el-input v-model="keyword" placeholder="按学号/姓名搜索" style="width:220px" @keyup.enter="load" />
          <el-button @click="load">查询</el-button>
          <el-button type="primary" @click="openCreate">新增学生</el-button>
        </div>
      </div>
    </template>

    <el-table :data="rows" stripe>
      <el-table-column prop="studentId" label="学号" />
      <el-table-column prop="studentName" label="姓名" />
      <el-table-column prop="major" label="专业" />
      <el-table-column prop="currentGrade" label="年级" />
      <el-table-column prop="studentType" label="类型" />
      <el-table-column label="操作" width="180">
        <template #default="scope">
          <el-button link type="primary" @click="openEdit(scope.row)">编辑</el-button>
          <el-button link type="danger" @click="remove(scope.row.studentId)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>

  <el-dialog v-model="visible" :title="isEdit ? '编辑学生' : '新增学生'" width="520px">
    <el-form label-width="90px">
      <el-form-item label="学号">
        <el-input v-model="form.studentId" :disabled="isEdit" />
      </el-form-item>
      <el-form-item label="姓名">
        <el-input v-model="form.studentName" />
      </el-form-item>
      <el-form-item label="专业">
        <el-input v-model="form.major" />
      </el-form-item>
      <el-form-item label="年级">
        <el-input v-model="form.currentGrade" />
      </el-form-item>
      <el-form-item label="类型">
        <el-select v-model="form.studentType" style="width:100%">
          <el-option label="本科生" value="本科生" />
          <el-option label="研究生" value="研究生" />
        </el-select>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible=false">取消</el-button>
      <el-button type="primary" @click="save">保存</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { createStudent, deleteStudent, getStudents, updateStudent, type StudentForm } from '../../api/student'

const keyword = ref('')
const rows = ref<StudentForm[]>([])
const visible = ref(false)
const isEdit = ref(false)
const form = reactive<StudentForm>({ studentId: '', studentName: '', major: '', currentGrade: '', studentType: '本科生' })

async function load() {
  const res = await getStudents(keyword.value)
  rows.value = res.data || []
}

function openCreate() {
  isEdit.value = false
  Object.assign(form, { studentId: '', studentName: '', major: '', currentGrade: '', studentType: '本科生' })
  visible.value = true
}

function openEdit(row: StudentForm) {
  isEdit.value = true
  Object.assign(form, row)
  visible.value = true
}

async function save() {
  if (!form.studentId || !form.studentName) {
    ElMessage.warning('学号和姓名不能为空')
    return
  }
  if (isEdit.value) {
    await updateStudent(form.studentId, form)
    ElMessage.success('修改成功')
  } else {
    await createStudent(form)
    ElMessage.success('新增成功')
  }
  visible.value = false
  await load()
}

async function remove(id: string) {
  await ElMessageBox.confirm(`确认删除学生 ${id} 吗？`, '提示', { type: 'warning' })
  await deleteStudent(id)
  ElMessage.success('删除成功')
  await load()
}

onMounted(load)
</script>
