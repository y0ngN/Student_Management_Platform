﻿<template>
  <el-card>
    <template #header>
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <span>竞赛获奖管理</span>
        <div style="display:flex;gap:8px">
          <el-input v-model="keyword" placeholder="学号/姓名/竞赛名称" style="width:220px" @keyup.enter="load" />
          <el-select v-model="auditStatus" clearable placeholder="审核状态" style="width:140px">
            <el-option label="待审核" value="待审核" />
            <el-option label="已通过" value="已通过" />
            <el-option label="已退回" value="已退回" />
          </el-select>
          <el-button @click="load">查询</el-button>
          <el-button type="primary" @click="openCreate">新增记录</el-button>
        </div>
      </div>
    </template>

    <el-table :data="rows" stripe>
      <el-table-column prop="awardId" label="ID" width="70" />
      <el-table-column prop="studentId" label="学号" />
      <el-table-column prop="realName" label="姓名" />
      <el-table-column prop="competitionName" label="竞赛名称" min-width="200" />
      <el-table-column prop="awardGrade" label="获奖等级" />
      <el-table-column prop="awardDate" label="获奖时间" />
      <el-table-column prop="auditStatus" label="审核状态" width="100" />
      <el-table-column label="操作" width="220">
        <template #default="scope">
          <el-button link type="primary" @click="openEdit(scope.row)">编辑</el-button>
          <el-button link @click="openAudit(scope.row)">审核</el-button>
          <el-button link type="danger" @click="remove(scope.row.awardId)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>

  <el-dialog v-model="visible" :title="isEdit ? '编辑竞赛记录' : '新增竞赛记录'" width="640px">
    <el-form label-width="100px">
      <el-form-item label="学号"><el-input v-model="form.studentId" /></el-form-item>
      <el-form-item label="姓名"><el-input v-model="form.realName" /></el-form-item>
      <el-form-item label="竞赛名称"><el-input v-model="form.competitionName" /></el-form-item>
      <el-form-item label="赛届"><el-input v-model="form.competitionSession" /></el-form-item>
      <el-form-item label="获奖等级"><el-input v-model="form.awardGrade" /></el-form-item>
      <el-form-item label="获奖时间"><el-input v-model="form.awardDate" placeholder="如 202605" /></el-form-item>
      <el-form-item label="备注"><el-input v-model="form.remarks" type="textarea" /></el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible=false">取消</el-button>
      <el-button type="primary" @click="save">保存</el-button>
    </template>
  </el-dialog>

  <el-dialog v-model="auditVisible" title="审核记录" width="520px">
    <el-form label-width="90px">
      <el-form-item label="审核状态">
        <el-select v-model="auditForm.auditStatus" style="width:100%">
          <el-option label="已通过" value="已通过" />
          <el-option label="已退回" value="已退回" />
        </el-select>
      </el-form-item>
      <el-form-item label="审核备注">
        <el-input v-model="auditForm.remarks" type="textarea" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="auditVisible=false">取消</el-button>
      <el-button type="primary" @click="submitAudit">提交审核</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  auditCompetitionAward,
  createCompetitionAward,
  deleteCompetitionAward,
  getCompetitionAwards,
  updateCompetitionAward,
  type CompetitionAwardForm
} from '../../api/competitionAward'

const keyword = ref('')
const auditStatus = ref('')
const rows = ref<CompetitionAwardForm[]>([])
const visible = ref(false)
const isEdit = ref(false)
const editingId = ref<number | null>(null)
const form = reactive<CompetitionAwardForm>({
  studentId: '',
  realName: '',
  competitionName: '',
  competitionSession: '',
  awardGrade: '',
  awardDate: '',
  remarks: ''
})

const auditVisible = ref(false)
const auditingId = ref<number | null>(null)
const auditForm = reactive({ auditStatus: '已通过', remarks: '' })

async function load() {
  const res = await getCompetitionAwards(keyword.value, auditStatus.value)
  rows.value = res.data || []
}

function openCreate() {
  isEdit.value = false
  editingId.value = null
  Object.assign(form, {
    studentId: '', realName: '', competitionName: '', competitionSession: '', awardGrade: '', awardDate: '', remarks: ''
  })
  visible.value = true
}

function openEdit(row: CompetitionAwardForm) {
  isEdit.value = true
  editingId.value = row.awardId || null
  Object.assign(form, row)
  visible.value = true
}

async function save() {
  if (!form.studentId || !form.realName || !form.competitionName) {
    ElMessage.warning('学号、姓名、竞赛名称不能为空')
    return
  }
  if (isEdit.value && editingId.value) {
    await updateCompetitionAward(editingId.value, form)
    ElMessage.success('修改成功')
  } else {
    await createCompetitionAward(form)
    ElMessage.success('新增成功')
  }
  visible.value = false
  await load()
}

async function remove(id: number) {
  await ElMessageBox.confirm(`确认删除记录 ${id} 吗？`, '提示', { type: 'warning' })
  await deleteCompetitionAward(id)
  ElMessage.success('删除成功')
  await load()
}

function openAudit(row: CompetitionAwardForm) {
  auditingId.value = row.awardId || null
  auditForm.auditStatus = '已通过'
  auditForm.remarks = row.remarks || ''
  auditVisible.value = true
}

async function submitAudit() {
  if (!auditingId.value) return
  await auditCompetitionAward(auditingId.value, auditForm.auditStatus, auditForm.remarks)
  ElMessage.success('审核完成')
  auditVisible.value = false
  await load()
}

onMounted(load)
</script>
