﻿<template>
  <el-row :gutter="16">
    <el-col :span="6"><el-card>学生总数：{{ stats.students }}</el-card></el-col>
    <el-col :span="6"><el-card>教职工总数：{{ stats.staff }}</el-card></el-col>
    <el-col :span="6"><el-card>当前角色：{{ role }}</el-card></el-col>
  </el-row>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive } from 'vue'
import { useAuthStore } from '../../stores/auth'
import { getStudents } from '../../api/student'
import { getStaff } from '../../api/staff'

const auth = useAuthStore()
const role = computed(() => auth.role)
const stats = reactive({ students: 0, staff: 0 })

onMounted(async () => {
  const s = await getStudents()
  const t = await getStaff()
  stats.students = s?.data?.length || 0
  stats.staff = t?.data?.length || 0
})
</script>
