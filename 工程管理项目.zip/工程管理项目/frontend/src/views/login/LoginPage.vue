﻿<template>
  <div style="height:100vh;display:flex;justify-content:center;align-items:center;background:#f5f7fa">
    <el-card style="width:380px">
      <h2 style="margin-bottom:16px">学生管理平台登录</h2>
      <el-form @submit.prevent>
        <el-form-item>
          <el-input v-model="form.username" placeholder="用户名" />
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.password" type="password" placeholder="密码" show-password />
        </el-form-item>
        <el-button type="primary" :loading="loading" style="width:100%" @click="onLogin">登录</el-button>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { login } from '../../api/auth'
import { useAuthStore } from '../../stores/auth'

const router = useRouter()
const authStore = useAuthStore()
const loading = ref(false)
const form = reactive({ username: '', password: '' })

async function onLogin() {
  if (!form.username || !form.password) {
    ElMessage.warning('请输入账号和密码')
    return
  }
  loading.value = true
  try {
    const res = await login(form.username, form.password)
    if (!res.success) {
      ElMessage.error(res.message || '登录失败')
      return
    }
    authStore.setAuth(res.data.token, res.data.username, res.data.role)
    ElMessage.success('登录成功')
    router.push('/')
  } catch (e) {
    ElMessage.error('登录请求失败，请检查后端服务')
  } finally {
    loading.value = false
  }
}
</script>
