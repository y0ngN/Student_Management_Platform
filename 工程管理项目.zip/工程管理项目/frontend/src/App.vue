﻿<template>
  <router-view />
</template>
