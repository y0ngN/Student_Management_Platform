﻿# 学生管理平台（前后端骨架）

## 目录

- `backend` Spring Boot 后端
- `frontend` Vue3 前端
- `学生管理系统后端数据库.sql` 你的数据库脚本

## 1. 数据库准备（SQL Server）

1. 创建数据库：`StudentManagement`
2. 执行 `学生管理系统后端数据库.sql`
3. 在 `Sys_User` 表插入测试账号（密码可先明文，后续改 BCrypt）

## 2. 后端启动

```bash
cd backend
mvn spring-boot:run
```

后端地址：`http://localhost:8080`

## 3. 前端启动

```bash
cd frontend
npm install
npm run dev
```

前端地址：`http://localhost:5173`

## 4. 已完成接口

- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/students`
- `GET /api/staff`
- `GET /api/health`

## 5. 下一步建议

1. 为 `students/staff` 补全新增、编辑、删除接口
2. 新建 `Edu_CompetitionAward` 的 CRUD + 审核接口
3. 将 `Sys_User.PasswordHash` 全部改为 BCrypt 存储
4. 引入 MyBatis-Plus，将 SQL 从 JdbcTemplate 迁移到 Mapper
