﻿-- 系统用户表：专门负责登录认证
CREATE TABLE Sys_User (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) UNIQUE NOT NULL, -- 存学号或工号
    PasswordHash NVARCHAR(255) NOT NULL,   -- 存加密后的密码
    Role NVARCHAR(20) NOT NULL,            -- 角色：'Student', 'Staff', 'Admin'
    RelatedID NVARCHAR(50),                -- 关键：对应 Base_Student.StudentID 或 Base_Staff.StaffID
    IsActive BIT DEFAULT 1                 -- 账号是否可用
);
-- 1. 部门/学院字典表
CREATE TABLE Dic_Department (
    DeptID INT PRIMARY KEY IDENTITY(1,1),
    DeptName NVARCHAR(100) NOT NULL, -- 如：计算机科学技术学院
    DeptType NVARCHAR(50)           -- 教学部门、行政部门
);

-- 2. 职称/岗位等级字典表
CREATE TABLE Dic_JobTitle (
    TitleID INT PRIMARY KEY IDENTITY(1,1),
    TitleName NVARCHAR(50) NOT NULL, -- 如：教授、副教授、讲师 
    TitleCategory NVARCHAR(50)      -- 教师类、管理类、工勤类 
);

-- 3. 竞赛分级字典表
CREATE TABLE Dic_CompetitionLevel (
    LevelID INT PRIMARY KEY IDENTITY(1,1),
    LevelName NVARCHAR(50) NOT NULL  -- 如：国赛、省赛、校级 
);
CREATE TABLE Base_Staff (
    StaffID NVARCHAR(50) PRIMARY KEY,      -- 教职工号 
    RealName NVARCHAR(50) NOT NULL,        -- 姓名 
    Gender NVARCHAR(10),                   -- 性别 
    IDCard VARCHAR(18) UNIQUE,             -- 身份证号 
    BirthDate DATE,                        -- 出生年月 
    DeptID INT FOREIGN KEY REFERENCES Dic_Department(DeptID),
    Phone VARCHAR(20),                     -- 手机号 [cite: 49]
    Email NVARCHAR(100),                   -- 邮箱 [cite: 47]
    EntryDate DATE,                        -- 来校时间/入职时间 
    StaffStatus NVARCHAR(20) DEFAULT '在职' -- 在职、离职、退休 [cite: 31]
);
CREATE TABLE Base_Student (
    StudentID NVARCHAR(50) PRIMARY KEY,    -- 学号 [cite: 6, 8]
    StudentName NVARCHAR(50) NOT NULL,     -- 姓名 [cite: 6, 8]
    Major NVARCHAR(100),                   -- 专业
    CurrentGrade NVARCHAR(20),             -- 年级 (如: 2026级) [cite: 3]
    StudentType NVARCHAR(20)               -- 本科生、研究生 [cite: 3, 4]
);


-----==================================教研部分======================================
-- 1. 竞赛获奖主表
-- 整合：学院统计格式、蓝桥杯统计格式、学校下发格式
-- =========================================================
CREATE TABLE Edu_CompetitionAward (
    AwardID INT PRIMARY KEY IDENTITY(1,1),
    -- 基础关联信息
    StudentID NVARCHAR(50) FOREIGN KEY REFERENCES Base_Student(StudentID), -- 学号 [cite: 93, 95]
    RealName NVARCHAR(50),                                                -- 姓名 [cite: 93, 95]
    DeptName NVARCHAR(100),                                               -- 所在学院 [cite: 90]
    
    -- 竞赛描述（学校与学院格式整合）
    CompetitionName NVARCHAR(200) NOT NULL, -- 竞赛名称 (按证书规范填报) [cite: 90]
    CompetitionSession NVARCHAR(50),        -- 赛届 [cite: 93, 95]
    CompetitionCategory NVARCHAR(50),       -- 赛类 [cite: 93, 95]
    LevelID INT FOREIGN KEY REFERENCES Dic_CompetitionLevel(LevelID),     -- 赛级 (获奖级别) [cite: 93, 95]
    SubjectGroup NVARCHAR(100),             -- 比赛科目/组别 (参赛赛道/组别) [cite: 90, 93, 95]
    AwardProjectName NVARCHAR(200),         -- 获奖项目/作品名称 [cite: 90]
    
    -- 获奖详情
    AwardGrade NVARCHAR(50),                -- 获奖等级 (奖项) [cite: 93, 95]
    OtherAwardLevel NVARCHAR(100),          -- 其他获奖等别/级别 [cite: 90]
    AwardDate CHAR(6),                      -- 获奖时间 (填报格式 202205) [cite: 90]
    HostUnit NVARCHAR(200),                 -- 主办单位 (注意不要填承办单位) [cite: 90]
    CertificateNumber NVARCHAR(100),        -- 证书编号 [cite: 90]
    AwardDocURL NVARCHAR(500),              -- 获奖批文或竞赛官网公示网址 [cite: 90]
    
    -- 团队/个人属性
    IsTeamAward NVARCHAR(20),               -- 团队获奖/个人获奖 (个人奖项不用填团队情况) [cite: 90]
    TeamSize INT,                           -- 团队人数 [cite: 90]
    MemberOrder INT,                        -- 个人位次 [cite: 90]
    TeamMembers NVARCHAR(MAX),              -- 团队成员姓名 (以顿号分隔开) [cite: 90]
    
    -- 指导教师
    PrimaryAdvisorID NVARCHAR(50) FOREIGN KEY REFERENCES Base_Staff(StaffID), -- 指导教师1 (教师姓名) [cite: 90, 93]
    PrimaryAdvisorDept NVARCHAR(100),                                         -- 指导教师1所在学院 [cite: 90]
    SecondaryAdvisorID NVARCHAR(50) FOREIGN KEY REFERENCES Base_Staff(StaffID),-- 指导教师2 (教师姓名) [cite: 90]
    SecondaryAdvisorDept NVARCHAR(100),                                        -- 指导教师2所在学院 [cite: 90]
    
    -- 管理状态
    AuditStatus NVARCHAR(20) DEFAULT '待审核', -- 审核状态
    Remarks NVARCHAR(MAX)                      -- 备注 [cite: 90]
);

-- =========================================================
-- 2. 大创项目表
-- 字段完全对应调研记录：项目名称,申报年限,申报时间,立项时间... [cite: 97]
-- =========================================================
CREATE TABLE Edu_InnovationProject (
    ProjectID INT PRIMARY KEY IDENTITY(1,1),
    ProjectName NVARCHAR(200) NOT NULL,     -- 项目名称 [cite: 97]
    ApplicationYear CHAR(4),                -- 申报年限 [cite: 97]
    ApplicationDate DATE,                   -- 申报时间 [cite: 97]
    ApprovalDate DATE,                      -- 立项时间 [cite: 97]
    ProjectCategory NVARCHAR(100),          -- 项目类别 [cite: 97]
    LeaderID NVARCHAR(50) FOREIGN KEY REFERENCES Base_Student(StudentID), -- 学生负责人 [cite: 97]
    TeamMembers NVARCHAR(MAX),              -- 参与成员 [cite: 97]
    AdvisorID NVARCHAR(50) FOREIGN KEY REFERENCES Base_Staff(StaffID),    -- 指导教师 [cite: 97]
    PrimaryDiscipline NVARCHAR(100),        -- 一级学科 [cite: 97]
    UnitName NVARCHAR(100),                 -- 单位 [cite: 97]
    ProjectBrief NVARCHAR(MAX),             -- 项目简介 [cite: 97]
    FaceStatus NVARCHAR(100),               -- 面貌 [cite: 97]
    SoftwareCopyright NVARCHAR(100),        -- 软著 [cite: 97]
    
    -- 附件管理
    PlanDoc NVARCHAR(500),                  -- 计划书 [cite: 97]
    ApprovalDoc NVARCHAR(500),              -- 立项书 [cite: 97]
    MidtermDoc NVARCHAR(500),               -- 中检书 [cite: 97]
    OtherAttachment NVARCHAR(500),          -- 其他附件 [cite: 97]
    
    IsExcellent BIT DEFAULT 0               -- 是否优秀 [cite: 97]
);

-- =========================================================
-- 3. 教研奖励表
-- 字段完全对应调研记录：序号,奖励名称,成果名称,获奖级别... [cite: 102]
-- =========================================================
CREATE TABLE Edu_TeachingAward (
    TeachingAwardID INT PRIMARY KEY IDENTITY(1,1),
    AwardName NVARCHAR(200) NOT NULL,       -- 奖励名称 [cite: 102]
    ResultName NVARCHAR(200),               -- 成果名称 [cite: 102]
    AwardLevel NVARCHAR(50),                -- 获奖级别 [cite: 102]
    AwardDate DATE,                         -- 获奖日期 [cite: 102]
    AllParticipants NVARCHAR(MAX),          -- 所有完成人 [cite: 102]
    IssuingAuthority NVARCHAR(200),         -- 发证机关 [cite: 102]
    AwardGrade NVARCHAR(50),                -- 获奖等级 [cite: 102]
    UnitRanking INT,                        -- 单位排名 [cite: 102]
    CertificateNumber NVARCHAR(100)         -- 证书号 [cite: 102]
);


---=====================科研部分====================
--科研项目模块
CREATE TABLE Res_Project (
    ProjectID INT PRIMARY KEY IDENTITY(1,1),

    ProjectCode NVARCHAR(100),    -- 项目编号
    ProjectName NVARCHAR(300),    -- 项目名称
    ProjectSource NVARCHAR(200),  -- 项目来源

    LeaderID NVARCHAR(50),        -- 负责人

    SignYear INT,                 -- 项目签署所属年度
    SignDate DATE,                -- 合同签订日期
    EndDate DATE,                 -- 合同截止日期

    ContractAmount DECIMAL(12,2), -- 合同金额
    ReceivedAmount DECIMAL(12,2), -- 到账金额

    FOREIGN KEY (LeaderID) REFERENCES Base_Staff(StaffID)
);
--科研奖励模块
CREATE TABLE Res_ResearchAward (
    AwardID INT PRIMARY KEY IDENTITY(1,1),

    AwardName NVARCHAR(200),      -- 奖励名称
    AchievementName NVARCHAR(300),-- 成果名称

    AwardLevel NVARCHAR(50),      -- 获奖级别
    AwardDate DATE,               -- 获奖日期

    CompletedBy NVARCHAR(500),    -- 所有完成人
    CertificateOrg NVARCHAR(200), -- 发证机关

    UnitRank NVARCHAR(50),        -- 获奖等级单位排名
    CertificateNo NVARCHAR(100),  -- 证书号

    MainAchievement NVARCHAR(500) -- 主要成果
);
--论文表
CREATE TABLE Res_Paper (
    PaperID INT PRIMARY KEY IDENTITY(1,1),
    PaperType NVARCHAR(50),         -- SCI / 卓越期刊 / CCF会议

    Title NVARCHAR(300) NOT NULL,   -- 论文题目
    JournalOrConf NVARCHAR(300),    -- 期刊/会议名称

    AuthorInfo NVARCHAR(500),       -- 作者信息
    FirstAuthorID NVARCHAR(50),     -- 一作
    CorrespondingAuthor NVARCHAR(200), -- 通讯作者

    PublishDate DATE,

    SCI_Zone NVARCHAR(50),          -- SCI分区
    CCF_Rank NVARCHAR(10),          -- CCF A/B/C
    IsRecommendedJournal BIT,       -- 是否推荐期刊
    IsTopJournal BIT,               -- 是否卓越/顶刊

    IsFirstUnit BIT,                -- 是否第一单位（青大）
    IsHighCited BIT,                -- 是否高被引

    PaperCategory NVARCHAR(50),     -- 论文归属
    Score INT,                      -- 积分

    Remark NVARCHAR(500),           -- ⭐调研要求：备注列

    FOREIGN KEY (FirstAuthorID) REFERENCES Base_Staff(StaffID)
);

------=====================人事======================================
	--学院人事记录
CREATE TABLE Staff_College_Detail (
    -- 教职工号 (严格作为主键并关联基础表)
    EmployeeID NVARCHAR(50) PRIMARY KEY FOREIGN KEY REFERENCES Base_Staff(StaffID), -- 教职工号 [cite: 27]
    
    -- 基础与时间信息
    FullName NVARCHAR(50),                -- 姓名 [cite: 28]
    Gender NVARCHAR(10),                  -- 性别 [cite: 25]
    Ethnicity NVARCHAR(20),               -- 民族 [cite: 25]
    BirthDate DATE,                       -- 出生年月 [cite: 29]
    Age INT,                              -- 年龄 [cite: 29]
    EntryDate DATE,                       -- 来校时间 [cite: 30]
    RetirementYear NVARCHAR(10),          -- 拟退休年 [cite: 31]
    Department NVARCHAR(100),             -- 部门 [cite: 32]
    
    -- 最高学历模块
    HighestEducation NVARCHAR(50),        -- 最高学历 [cite: 34]
    HighestDegree NVARCHAR(50),           -- 最高学位 [cite: 33]
    HighestEduSchool NVARCHAR(100),       -- 最高学历毕业院校 [cite: 34]
    HighestEduMajor NVARCHAR(100),        -- 所学专业 [cite: 35]
    HighestEduCategory NVARCHAR(100),     -- 所属门类 [cite: 35]
    HighestEduStartDate DATE,             -- 最高学历开始时间 [cite: 36]
    HighestEduEndDate DATE,               -- 最高学历毕业时间 [cite: 36]
    
    
    -- 政治面貌与职务
    PoliticalAffiliation NVARCHAR(50),    -- 党派 [cite: 37]
    JoinPartyDate DATE,                   -- 入党时间 [cite: 37]
    FullMemberDate DATE,                  -- 转正时间 [cite: 38]
    PartyAdminPost NVARCHAR(100),         -- 党政职务 [cite: 38]
    AppointDate DATE,                     -- 任职时间 [cite: 38]
    
    --职称与岗位
    JobTitle NVARCHAR(100),               -- 职称 [cite: 40]
    TitleEvalDate DATE,                   -- 评聘时间 [cite: 41]
    Category NVARCHAR(50),                -- 分类 [cite: 39]
    PostPosition NVARCHAR(100),           -- 岗位 [cite: 40]
    CurrentPostAppointDate DATE,          -- 现岗位聘用时间 [cite: 41]
    
    -- 个人身份与人才
    IDCardNumber VARCHAR(18),             -- 身份证号 [cite: 57]
    PhoneNumber VARCHAR(20),              -- 手机号 [cite: 49]
    TalentTitle NVARCHAR(100),            -- 人才称号 [cite: 42]
    TalentEvalDate DATE,                  -- 人才评聘时间 [cite: 43]
    Remarks NVARCHAR(MAX),                -- 备注 [cite: 82]
    HomeAddress NVARCHAR(255),            -- 住址 [cite: 70]
    
    --第一学历模块
    FirstEducation NVARCHAR(50),          -- 第一学历 [cite: 44]
    FirstDegree NVARCHAR(50),             -- 第一学位 [cite: 44]
    FirstEduGradDate DATE,                -- 毕业时间 [cite: 44]
    FirstEduSchool NVARCHAR(100),         -- 毕业院校 [cite: 45]
    FirstEduMajor NVARCHAR(100),          -- 所学专业 [cite: 46]
    
    -- 个人背景补充
    Email NVARCHAR(100),                  -- 邮箱 [cite: 47]
    MaritalStatus NVARCHAR(20),           -- 婚否 [cite: 48]
    EmergencyContact NVARCHAR(50),        -- 紧急联系人 [cite: 49]
    EmergencyPhone VARCHAR(20),           -- 紧急联系人手机号 [cite: 49]
    NativePlace NVARCHAR(100)             -- 籍贯 [cite: 50]
);
CREATE TABLE Staff_University_Record (
    -- 1. 唯一标识与关联
    RecordKey NVARCHAR(100) PRIMARY KEY,           -- 记录主键 
    EmployeeID NVARCHAR(50) NOT NULL FOREIGN KEY REFERENCES Base_Staff(StaffID), -- 教职工号 
    
    -- 2. 身份与基本背景
    FullName NVARCHAR(50),                         -- 姓名 
    NamePinyin NVARCHAR(100),                      -- 姓名拼音 
    Gender NVARCHAR(10),                           -- 性别 
    BirthDate DATE,                                -- 出生日期 
    Age INT,                                       -- 年龄 
    NativePlace NVARCHAR(100),                     -- 籍贯 
    Nationality NVARCHAR(50),                      -- 国籍(地区) 
    Ethnicity NVARCHAR(20),                        -- 民族 
    StartWorkDate DATE,                            -- 参加工作年月 
    TeachingStartDate DATE,                        -- 从教年月 
    PoliticalStatus NVARCHAR(50),                  -- 政治面貌 
    JoinPartyDate DATE,                            -- 参加党派日期 
    ExpectedRetirementDate DATE,                   -- 预计离退休日期 
    ArchivesBirthDate DATE,                        -- 档案出生日期 
    
    -- 3. 学历学位详细 (学校层面)
    HighestEducation NVARCHAR(50),                 -- 最高学历 
    GraduationDate DATE,                           -- 毕业年月 [cite: 52]
    GraduationSchool NVARCHAR(100),                -- 毕业学校 [cite: 53]
    MajorName NVARCHAR(100),                       -- 所学专业 [cite: 54]
    HighestDegree NVARCHAR(50),                    -- 最高学位 [cite: 55]
    DegreeDate DATE,                               -- 授予学位年月 [cite: 55]
    DegreeGrantingUnit NVARCHAR(100),              -- 授予学位单位 [cite: 56]
    
    -- 4. 岗位与类别属性
    EntryDate DATE,                                -- 来校年月 
    StaffSource NVARCHAR(50),                      -- 教职工来源 
    StaffCategory NVARCHAR(50),                    -- 教职工类别 
    PersonalIdentity NVARCHAR(50),                 -- 个人身份 [cite: 57]
    CurrentStatus NVARCHAR(20),                    -- 当前状态 
    SecondaryUnit NVARCHAR(100),                   -- 二级单位 [cite: 69]
    TeacherType NVARCHAR(50),                      -- 教师类型 
    CurrentDepartment NVARCHAR(100),               -- 所在部门 [cite: 58]
    
    -- 5. 职务与学科信息
    AdminPostLevel NVARCHAR(50),                   -- 党政职务级别 [cite: 59]
    MainAdminPost NVARCHAR(100),                   -- 党政主职 [cite: 59]
    AppointmentDept NVARCHAR(100),                 -- 任职部门 [cite: 59]
    PrimaryLevel NVARCHAR(50),                     -- 主职级别 [cite: 59]
    TeacherCertNumber NVARCHAR(100),               -- 教师资格证号 
    TeacherCertDate DATE,                          -- 教师资格获得日期 
    SubjectCategory NVARCHAR(50),                  -- 学科类别 
    FirstLevelSubject NVARCHAR(100),               -- 一级学科 [cite: 60]
    SecondLevelSubject NVARCHAR(100),              -- 二级学科 [cite: 61]
    ResearchDirection NVARCHAR(100),               -- 研究方向 [cite: 62]
    
    -- 6. 资格与聘任标识
    IsFullTimePsychConsultant BIT,                 -- 是否专职从事心理咨询工作 [cite: 62]
    HasPsychCert BIT,                              -- 是否持有心理咨询资格证书 [cite: 63]
    ProfessionalTitle NVARCHAR(100),               -- 专业技术职务 [cite: 64]
    TitleLevel NVARCHAR(50),                       -- 专业技术职务级别 [cite: 65]
    TitleEvalDate DATE,                            -- 专业技术职务评定年月 [cite: 66]
    IsManagementPost BIT,                          -- 是否管理岗位 [cite: 67]
    IsTechnicalPost BIT,                           -- 是否专业技术岗位 [cite: 67]
    TechnicalPostCategory NVARCHAR(50),            -- 专业技术岗位类别 [cite: 67]
    IsWorkPost BIT,                                -- 是否工勤岗位 [cite: 67]
    AppointmentPost NVARCHAR(100),                 -- 聘任岗位 [cite: 68]
    AppointmentPostLevel NVARCHAR(50),             -- 聘任岗位等级 [cite: 71]
    PostAppointmentDate DATE,                      -- 岗位聘任时间 [cite: 71]
    PartTimePost NVARCHAR(100),                    -- 兼聘岗位 [cite: 71]
    PartTimePostLevel NVARCHAR(50),                -- 兼聘岗位等级 [cite: 71]
    PartTimeDate DATE,                             -- 兼聘日期 [cite: 71]
    
    -- 7. 专项人才标识
    IsIndustryPersonnel BIT,                       -- 是否产业人员 [cite: 71]
    IsDualRole BIT,                                -- 是否双肩挑 
    DualRoleUnit NVARCHAR(100),                    -- 双肩挑所在单位 [cite: 73]
    IsDoubleQualified BIT,                         -- 是否双师型教师 
    IsTeachingUndergrad BIT,                       -- 是否为本科生上课 
    CounselorCategory NVARCHAR(50)                 -- 辅导员类别 [cite: 75]
);
	--学校人事记录
CREATE TABLE Staff_University_Detail (
    -- 1. 记录标识与关联
    RecordKey NVARCHAR(100) PRIMARY KEY,           -- 记录主键 [cite: 51]
    EmployeeID NVARCHAR(50) NOT NULL FOREIGN KEY REFERENCES Base_Staff(StaffID), -- 教职工号 [cite: 51]
    
    -- 2. 基础身份信息
    FullName NVARCHAR(50),                         -- 姓名 [cite: 51]
    NamePinyin NVARCHAR(100),                      -- 姓名拼音 [cite: 51]
    Gender NVARCHAR(10),                           -- 性别 [cite: 51]
    BirthDate DATE,                                -- 出生日期 [cite: 51]
    Age INT,                                       -- 年龄 [cite: 51]
    NativePlace NVARCHAR(100),                     -- 籍贯 [cite: 51]
    Nationality NVARCHAR(50),                      -- 国籍(地区) [cite: 51]
    Ethnicity NVARCHAR(20),                        -- 民族 [cite: 51]
    StartWorkDate DATE,                            -- 参加工作年月 [cite: 62]
    TeachingStartDate DATE,                        -- 从教年月 [cite: 51]
    PoliticalStatus NVARCHAR(50),                  -- 政治面貌 [cite: 51]
    JoinPartyDate DATE,                            -- 参加党派日期 [cite: 51]
    ExpectedRetirementDate DATE,                   -- 预计离退休日期 [cite: 51]
    ArchivesBirthDate DATE,                        -- 档案出生日期 [cite: 51]
    
    -- 3. 学历学位模块
    HighestEducation NVARCHAR(50),                 -- 最高学历 [cite: 51]
    GraduationDate DATE,                           -- 毕业年月 [cite: 51]
    GraduationSchool NVARCHAR(100),                -- 毕业学校 [cite: 53]
    MajorName NVARCHAR(100),                       -- 所学专业 [cite: 54]
    HighestDegree NVARCHAR(50),                    -- 最高学位 [cite: 55]
    DegreeDate DATE,                               -- 授予学位年月 [cite: 51]
    DegreeGrantingUnit NVARCHAR(100),              -- 授予学位单位 [cite: 56]
    
    -- 4. 来源与状态
    EntryDate DATE,                                -- 来校年月 [cite: 51]
    StaffSource NVARCHAR(50),                      -- 教职工来源 [cite: 51]
    StaffCategory NVARCHAR(50),                    -- 教职工类别 [cite: 51]
    PersonalIdentity NVARCHAR(50),                 -- 个人身份 [cite: 57]
    CurrentStatus NVARCHAR(20),                    -- 当前状态 [cite: 51]
    SecondaryUnit NVARCHAR(100),                   -- 二级单位 [cite: 51]
    TeacherType NVARCHAR(50),                      -- 教师类型 [cite: 51]
    CurrentDepartment NVARCHAR(100),               -- 所在部门 [cite: 58]
    
    -- 5. 职务与学科
    AdminPostLevel NVARCHAR(50),                   -- 党政职务级别 [cite: 51]
    MainAdminPost NVARCHAR(100),                   -- 党政主职 [cite: 51]
    AppointmentDept NVARCHAR(100),                 -- 任职部门 [cite: 51]
    PrimaryLevel NVARCHAR(50),                     -- 主职级别 [cite: 51]
    TeacherCertNumber NVARCHAR(100),               -- 教师资格证号 [cite: 63]
    TeacherCertDate DATE,                          -- 教师资格获得日期 [cite: 51]
    SubjectCategory NVARCHAR(50),                  -- 学科类别 [cite: 51]
    FirstLevelSubject NVARCHAR(100),               -- 一级学科 [cite: 60]
    SecondLevelSubject NVARCHAR(100),              -- 二级学科 [cite: 61]
    ResearchDirection NVARCHAR(100),               -- 研究方向 [cite: 62]
    
    -- 6. 岗位与职称
    IsFullTimePsychConsultant BIT,                 -- 是否专职从事心理咨询工作 [cite: 62]
    HasPsychCert BIT,                              -- 是否持有心理咨询资格证书 [cite: 63]
    ProfessionalTitle NVARCHAR(100),               -- 专业技术职务 [cite: 64]
    TitleLevel NVARCHAR(50),                       -- 专业技术职务级别 [cite: 65]
    TitleEvalDate DATE,                            -- 专业技术职务评定年月 [cite: 66]
    IsManagementPost BIT,                          -- 是否管理岗位 [cite: 51]
    IsTechnicalPost BIT,                           -- 是否专业技术岗位 [cite: 67]
    TechnicalPostCategory NVARCHAR(50),            -- 专业技术岗位类别 [cite: 51]
    IsWorkPost BIT,                                -- 是否工勤岗位 [cite: 51]
    AppointmentPost NVARCHAR(100),                 -- 聘任岗位 [cite: 68]
    AppointmentPostLevel NVARCHAR(50),             -- 聘任岗位等级 [cite: 51]
    PostAppointmentDate DATE,                      -- 岗位聘任时间 [cite: 51]
    
    -- 7. 兼聘与专项信息
    PartTimePost NVARCHAR(100),                    -- 兼聘岗位 [cite: 51]
    PartTimePostLevel NVARCHAR(50),                -- 兼聘岗位等级 [cite: 71]
    PartTimeDate DATE,                             -- 兼聘日期 [cite: 71]
    IsIndustryPersonnel BIT,                       -- 是否产业人员 [cite: 71]
    IsDualRole BIT,                                -- 是否双肩挑 
    DualRoleUnit NVARCHAR(100),                    -- 双肩挑所在单位 [cite: 73]
    IsDoubleQualified BIT,                         -- 是否双师型教师 
    IsTeachingUndergrad BIT,                       -- 是否为本科生上课 
    CounselorCategory NVARCHAR(50)                 -- 辅导员类别 [cite: 75]
);
	--个人荣誉
CREATE TABLE Staff_Honors_Detail (
    -- 1. 关联基础表
    EmployeeID NVARCHAR(50) NOT NULL FOREIGN KEY REFERENCES Base_Staff(StaffID), -- 教职工号 
    
    -- 2. 荣誉称号核心信息 (严格按照图片表头顺序)
    AwardYear INT,                                -- 获奖年度 [cite: 77]
    AwardUnitOrPerson NVARCHAR(100),              -- 获奖单位/个人 [cite: 77]
    HonorName NVARCHAR(200),                      -- 奖励 (荣誉) 名称 [cite: 78]
    
    -- 级别建议关联之前的 Dic_CompetitionLevel
    AwardLevel NVARCHAR(50),                      -- 奖励 (比赛) 级别 [cite: 76]
    
    IssuingAuthority NVARCHAR(200),               -- 表彰单位 [cite: 79]
    DocNumber NVARCHAR(100),                      -- 发文年号 [cite: 80]
    IssueDate DATE,                               -- 发文日期 [cite: 81]
    Remarks NVARCHAR(MAX),                        -- 备注 [cite: 82]

    -- 建议增加一个主键 ID 方便单条记录维护
    RecordID INT IDENTITY(1,1) PRIMARY KEY
);