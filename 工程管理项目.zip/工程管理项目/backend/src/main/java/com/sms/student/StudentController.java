﻿package com.sms.student;

import com.sms.common.api.ApiResponse;
import jakarta.validation.constraints.NotBlank;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final JdbcTemplate jdbcTemplate;

    public StudentController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping
    public ApiResponse<List<StudentDto>> list(@RequestParam(required = false) String keyword) {
        String baseSql = "SELECT StudentID, StudentName, Major, CurrentGrade, StudentType FROM Base_Student";
        List<StudentDto> data;
        if (keyword == null || keyword.isBlank()) {
            data = jdbcTemplate.query(baseSql + " ORDER BY StudentID", (rs, i) -> new StudentDto(
                    rs.getString("StudentID"),
                    rs.getString("StudentName"),
                    rs.getString("Major"),
                    rs.getString("CurrentGrade"),
                    rs.getString("StudentType")
            ));
        } else {
            String sql = baseSql + " WHERE StudentID LIKE ? OR StudentName LIKE ? ORDER BY StudentID";
            String like = "%" + keyword.trim() + "%";
            data = jdbcTemplate.query(sql, (rs, i) -> new StudentDto(
                    rs.getString("StudentID"),
                    rs.getString("StudentName"),
                    rs.getString("Major"),
                    rs.getString("CurrentGrade"),
                    rs.getString("StudentType")
            ), like, like);
        }
        return ApiResponse.ok(data);
    }

    @PostMapping
    public ApiResponse<Object> create(@RequestBody StudentUpsertRequest req) {
        String sql = "INSERT INTO Base_Student(StudentID, StudentName, Major, CurrentGrade, StudentType) VALUES(?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, req.studentId(), req.studentName(), req.major(), req.currentGrade(), req.studentType());
        return ApiResponse.ok("created");
    }

    @PutMapping("/{id}")
    public ApiResponse<Object> update(@PathVariable String id, @RequestBody StudentUpsertRequest req) {
        String sql = "UPDATE Base_Student SET StudentName=?, Major=?, CurrentGrade=?, StudentType=? WHERE StudentID=?";
        jdbcTemplate.update(sql, req.studentName(), req.major(), req.currentGrade(), req.studentType(), id);
        return ApiResponse.ok("updated");
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> delete(@PathVariable String id) {
        jdbcTemplate.update("DELETE FROM Base_Student WHERE StudentID=?", id);
        return ApiResponse.ok("deleted");
    }

    public record StudentUpsertRequest(
            @NotBlank String studentId,
            @NotBlank String studentName,
            String major,
            String currentGrade,
            String studentType
    ) {}
}
