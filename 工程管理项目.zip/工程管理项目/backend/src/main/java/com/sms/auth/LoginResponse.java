﻿package com.sms.auth;

public record LoginResponse(String token, String username, String role) {}
