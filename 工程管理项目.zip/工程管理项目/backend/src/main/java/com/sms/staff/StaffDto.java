﻿package com.sms.staff;

public record StaffDto(String staffId, String realName, String gender, String phone, String email, String staffStatus) {}
