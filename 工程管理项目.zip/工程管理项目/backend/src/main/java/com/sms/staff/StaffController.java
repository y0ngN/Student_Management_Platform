﻿package com.sms.staff;

import com.sms.common.api.ApiResponse;
import jakarta.validation.constraints.NotBlank;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/staff")
public class StaffController {
    private final JdbcTemplate jdbcTemplate;

    public StaffController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping
    public ApiResponse<List<StaffDto>> list(@RequestParam(required = false) String keyword) {
        String baseSql = "SELECT StaffID, RealName, Gender, Phone, Email, StaffStatus FROM Base_Staff";
        List<StaffDto> data;
        if (keyword == null || keyword.isBlank()) {
            data = jdbcTemplate.query(baseSql + " ORDER BY StaffID", (rs, i) -> new StaffDto(
                    rs.getString("StaffID"),
                    rs.getString("RealName"),
                    rs.getString("Gender"),
                    rs.getString("Phone"),
                    rs.getString("Email"),
                    rs.getString("StaffStatus")
            ));
        } else {
            String sql = baseSql + " WHERE StaffID LIKE ? OR RealName LIKE ? ORDER BY StaffID";
            String like = "%" + keyword.trim() + "%";
            data = jdbcTemplate.query(sql, (rs, i) -> new StaffDto(
                    rs.getString("StaffID"),
                    rs.getString("RealName"),
                    rs.getString("Gender"),
                    rs.getString("Phone"),
                    rs.getString("Email"),
                    rs.getString("StaffStatus")
            ), like, like);
        }
        return ApiResponse.ok(data);
    }

    @PostMapping
    public ApiResponse<Object> create(@RequestBody StaffUpsertRequest req) {
        String sql = "INSERT INTO Base_Staff(StaffID, RealName, Gender, Phone, Email, StaffStatus) VALUES(?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, req.staffId(), req.realName(), req.gender(), req.phone(), req.email(), req.staffStatus());
        return ApiResponse.ok("created");
    }

    @PutMapping("/{id}")
    public ApiResponse<Object> update(@PathVariable String id, @RequestBody StaffUpsertRequest req) {
        String sql = "UPDATE Base_Staff SET RealName=?, Gender=?, Phone=?, Email=?, StaffStatus=? WHERE StaffID=?";
        jdbcTemplate.update(sql, req.realName(), req.gender(), req.phone(), req.email(), req.staffStatus(), id);
        return ApiResponse.ok("updated");
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> delete(@PathVariable String id) {
        jdbcTemplate.update("DELETE FROM Base_Staff WHERE StaffID=?", id);
        return ApiResponse.ok("deleted");
    }

    public record StaffUpsertRequest(
            @NotBlank String staffId,
            @NotBlank String realName,
            String gender,
            String phone,
            String email,
            String staffStatus
    ) {}
}
