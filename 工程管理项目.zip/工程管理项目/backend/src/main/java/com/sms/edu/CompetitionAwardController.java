package com.sms.edu;

import com.sms.common.api.ApiResponse;
import jakarta.validation.constraints.NotBlank;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/edu/competition-awards")
public class CompetitionAwardController {
    private final JdbcTemplate jdbcTemplate;

    public CompetitionAwardController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping
    public ApiResponse<List<CompetitionAwardDto>> list(@RequestParam(required = false) String keyword,
                                                        @RequestParam(required = false) String auditStatus) {
        StringBuilder sql = new StringBuilder("SELECT AwardID, StudentID, RealName, CompetitionName, CompetitionSession, AwardGrade, AwardDate, AuditStatus, Remarks FROM Edu_CompetitionAward WHERE 1=1");
        var params = new java.util.ArrayList<Object>();
        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND (StudentID LIKE ? OR RealName LIKE ? OR CompetitionName LIKE ?)");
            String like = "%" + keyword.trim() + "%";
            params.add(like);
            params.add(like);
            params.add(like);
        }
        if (auditStatus != null && !auditStatus.isBlank()) {
            sql.append(" AND AuditStatus = ?");
            params.add(auditStatus);
        }
        sql.append(" ORDER BY AwardID DESC");

        var data = jdbcTemplate.query(sql.toString(), (rs, i) -> new CompetitionAwardDto(
                rs.getInt("AwardID"),
                rs.getString("StudentID"),
                rs.getString("RealName"),
                rs.getString("CompetitionName"),
                rs.getString("CompetitionSession"),
                rs.getString("AwardGrade"),
                rs.getString("AwardDate"),
                rs.getString("AuditStatus"),
                rs.getString("Remarks")
        ), params.toArray());
        return ApiResponse.ok(data);
    }

    @PostMapping
    public ApiResponse<Object> create(@RequestBody CompetitionAwardUpsertRequest req) {
        String sql = "INSERT INTO Edu_CompetitionAward(StudentID, RealName, CompetitionName, CompetitionSession, AwardGrade, AwardDate, AuditStatus, Remarks) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                req.studentId(),
                req.realName(),
                req.competitionName(),
                req.competitionSession(),
                req.awardGrade(),
                req.awardDate(),
                req.auditStatus() == null || req.auditStatus().isBlank() ? "待审核" : req.auditStatus(),
                req.remarks());
        return ApiResponse.ok("created");
    }

    @PutMapping("/{id}")
    public ApiResponse<Object> update(@PathVariable Integer id, @RequestBody CompetitionAwardUpsertRequest req) {
        String sql = "UPDATE Edu_CompetitionAward SET StudentID=?, RealName=?, CompetitionName=?, CompetitionSession=?, AwardGrade=?, AwardDate=?, Remarks=? WHERE AwardID=?";
        jdbcTemplate.update(sql,
                req.studentId(),
                req.realName(),
                req.competitionName(),
                req.competitionSession(),
                req.awardGrade(),
                req.awardDate(),
                req.remarks(),
                id);
        return ApiResponse.ok("updated");
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> delete(@PathVariable Integer id) {
        jdbcTemplate.update("DELETE FROM Edu_CompetitionAward WHERE AwardID=?", id);
        return ApiResponse.ok("deleted");
    }

    @PatchMapping("/{id}/audit")
    public ApiResponse<Object> audit(@PathVariable Integer id, @RequestBody CompetitionAwardAuditRequest req) {
        String sql = "UPDATE Edu_CompetitionAward SET AuditStatus=?, Remarks=? WHERE AwardID=?";
        jdbcTemplate.update(sql, req.auditStatus(), req.remarks(), id);
        return ApiResponse.ok("audited");
    }

    public record CompetitionAwardUpsertRequest(
            @NotBlank String studentId,
            @NotBlank String realName,
            @NotBlank String competitionName,
            String competitionSession,
            String awardGrade,
            String awardDate,
            String auditStatus,
            String remarks
    ) {}

    public record CompetitionAwardAuditRequest(
            @NotBlank String auditStatus,
            String remarks
    ) {}
}
