﻿package com.sms.student;

public record StudentDto(String studentId, String studentName, String major, String currentGrade, String studentType) {}
