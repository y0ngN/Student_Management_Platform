﻿package com.sms.edu;

public record CompetitionAwardDto(
        Integer awardId,
        String studentId,
        String realName,
        String competitionName,
        String competitionSession,
        String awardGrade,
        String awardDate,
        String auditStatus,
        String remarks
) {}
