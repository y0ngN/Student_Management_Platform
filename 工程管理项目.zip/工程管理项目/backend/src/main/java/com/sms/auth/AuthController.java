﻿package com.sms.auth;

import com.sms.common.api.ApiResponse;
import com.sms.common.security.JwtService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final JdbcTemplate jdbcTemplate;
    private final JwtService jwtService;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public AuthController(JdbcTemplate jdbcTemplate, JwtService jwtService) {
        this.jdbcTemplate = jdbcTemplate;
        this.jwtService = jwtService;
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest req) {
        var sql = "SELECT TOP 1 Username, PasswordHash, Role, IsActive FROM Sys_User WHERE Username = ?";
        var list = jdbcTemplate.queryForList(sql, req.username());
        if (list.isEmpty()) {
            return ResponseEntity.badRequest().body(ApiResponse.fail("用户名或密码错误"));
        }
        Map<String, Object> row = list.get(0);
        boolean active = ((Boolean) row.get("IsActive"));
        if (!active) {
            return ResponseEntity.badRequest().body(ApiResponse.fail("账号已禁用"));
        }
        String hash = (String) row.get("PasswordHash");
        if (!passwordEncoder.matches(req.password(), hash) && !req.password().equals(hash)) {
            return ResponseEntity.badRequest().body(ApiResponse.fail("用户名或密码错误"));
        }
        String username = (String) row.get("Username");
        String role = (String) row.get("Role");
        String token = jwtService.createToken(username, role);
        return ResponseEntity.ok(ApiResponse.ok(new LoginResponse(token, username, role)));
    }

    @GetMapping("/me")
    public ApiResponse<Object> me(@RequestHeader(name = "Authorization", required = false) String auth) {
        if (auth == null || !auth.startsWith("Bearer ")) {
            return ApiResponse.fail("未登录");
        }
        var jwt = jwtService.verify(auth.substring(7));
        return ApiResponse.ok(Map.of("username", jwt.getSubject(), "role", jwt.getClaim("role").asString()));
    }
}
